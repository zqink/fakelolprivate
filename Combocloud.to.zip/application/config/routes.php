<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['auth'] = 'auth/index';
$route['auth/login'] = 'auth/login';
$route['auth/signup'] = 'auth/signup';
$route['dashboard/combogroup/(:any)'] = 'dashboard/combogroup/$1';
$route['default_controller'] = 'home/index';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
