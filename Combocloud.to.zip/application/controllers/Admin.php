<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	public function index() {
		if (!$this->auth_model->is_logged_in()) {
			show_404();
		}
		if (!$this->auth_model->is_admin()) {
			show_404();
		}
		$data['is_adminpage'] = true;

		$data['title'] = 'Dashboard';
		$data['user_data'] = $this->auth_model->get_userdata();
		
		$data['statistics'] = $this->dashboard_model->get_statistics();

		$this->load->view('templates/header_new', $data);
		$this->load->view('admin/index_new');
		$this->load->view('templates/footer_new');
	}
	public function add_combo() {
		if (!$this->auth_model->is_logged_in()) {
			show_404();
		}
		if (!$this->auth_model->is_admin()) {
			show_404();
		}
		$data['is_adminpage'] = true;

		$data['title'] = 'Add Combo | Admin';
		$data['user_data'] = $this->auth_model->get_userdata();

		$data['combo_groups'] = $this->dashboard_model->get_combo_groups();
		$data['countries'] = $this->admin_model->countries_array();

		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('group', 'Group', 'required');
		$this->form_validation->set_rules('country_code', 'Country', 'required');
		if ($this->form_validation->run()) {
	        $config['upload_path']          = './uploads/';
	        $config['allowed_types']        = 'txt';

	        $this->upload->initialize($config);
	        if (!$this->upload->do_upload('userfile')) {
				$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'Sorry, there was a problem while uploading!'));
				redirect('admin/add_combo');
	        } else {
	        	$file_data = $this->upload->data();
	        	if ($this->admin_model->add_combo($file_data)) {
					$this->session->set_flashdata('messages', array('status' => 'success', 'message' => 'List has been successfully added!'));
	        	} else {
					$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'Sorry, there was a problem while adding the entry!'));
	        	}
	        	unlink($file_data['full_path']);
	        }
	    }


		$this->load->view('templates/header_new', $data);
		$this->load->view('admin/add_combo_new');
		$this->load->view('templates/footer_new');
	}
	public function delete_combo() {
		if (!$this->auth_model->is_logged_in()) {
			show_404();
		}
		if (!$this->auth_model->is_admin()) {
			show_404();
		}
		$data['is_adminpage'] = true;

		$data['title'] = 'Delete Combo | Admin';
		$data['user_data'] = $this->auth_model->get_userdata();
		$data['combolists'] = $this->dashboard_model->get_all_combolists();

		$this->form_validation->set_rules('combo', 'Combo', 'required|is_natural_no_zero');
		if ($this->form_validation->run()) {
			if ($this->admin_model->delete_combo()) {
				$this->session->set_flashdata('messages', array('status' => 'success', 'message' => 'List has been successfully deleted!'));
	        } else {
				$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'Sorry, there was a problem while deleting the entry!'));
	        }
		}

		$this->load->view('templates/header_new', $data);
		$this->load->view('admin/delete_combo_new');
		$this->load->view('templates/footer_new');
	}
	public function add_category() {
		if (!$this->auth_model->is_logged_in()) {
			show_404();
		}
		if (!$this->auth_model->is_admin()) {
			show_404();
		}
		$data['is_adminpage'] = true;

		$data['title'] = 'Add Group | Admin';
		$data['user_data'] = $this->auth_model->get_userdata();

		$this->form_validation->set_rules('name', 'Group Name', 'required');
		if ($this->form_validation->run()) {
			if ($this->admin_model->add_category()) {
				$this->session->set_flashdata('messages', array('status' => 'success', 'message' => 'Group has been successfully deleted!'));
	        } else {
				$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'Sorry, there was a problem while creating the entry!'));
	        }
		}

		$this->load->view('templates/header_new', $data);
		$this->load->view('admin/add_category_new');
		$this->load->view('templates/footer_new');
	}
	public function delete_category() {
		if (!$this->auth_model->is_logged_in()) {
			show_404();
		}
		if (!$this->auth_model->is_admin()) {
			show_404();
		}
		$data['is_adminpage'] = true;

		$data['title'] = 'Delete Group | Admin';
		$data['user_data'] = $this->auth_model->get_userdata();

		$data['combo_groups'] = $this->dashboard_model->get_combo_groups();

		$this->form_validation->set_rules('group', 'Group', 'required|is_natural_no_zero');
		if ($this->form_validation->run()) {
			if ($this->admin_model->delete_category()) {
				$this->session->set_flashdata('messages', array('status' => 'success', 'message' => 'Group has been successfully deleted!'));
	        } else {
				$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'Sorry, there was a problem while deleting the entries!'));
	        }
		}

		$this->load->view('templates/header_new', $data);
		$this->load->view('admin/delete_category_new');
		$this->load->view('templates/footer_new');
	}
	public function key_generator() {
		if (!$this->auth_model->is_logged_in()) {
			show_404();
		}
		if (!$this->auth_model->is_admin()) {
			show_404();
		}
		$data['is_adminpage'] = true;

		$data['title'] = 'Generate Keys | Admin';
		$data['user_data'] = $this->auth_model->get_userdata();

		$this->form_validation->set_rules('amount', 'Amount', 'required|is_natural_no_zero');
		$this->form_validation->set_rules('days_valid', 'Days Valid', 'required|is_natural_no_zero');

		if ($this->form_validation->run()) {
			$data['add_key_response'] = $this->admin_model->add_keys();
			if ($data['add_key_response']) {
				$this->session->set_flashdata('messages', array('status' => 'success', 'message' => 'Keys have been created!'));
			} else {
				$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'An error occured while creating new keys!'));
			}
		}

		$this->load->view('templates/header_new', $data);
		$this->load->view('admin/key_generator_new');
		$this->load->view('templates/footer_new');
	}
	public function manage_bans() {
		if (!$this->auth_model->is_logged_in()) {
			show_404();
		}
		if (!$this->auth_model->is_admin()) {
			show_404();
		}
		$data['is_adminpage'] = true;

		$data['title'] = 'Manage Bans | Admin';
		$data['user_data'] = $this->auth_model->get_userdata();

		$data['banned_members'] = $this->admin_model->get_banned_members();
		$data['banable_members'] = $this->admin_model->get_banableuserlist();

		$this->load->view('templates/header_new', $data);
		$this->load->view('admin/manage_bans_new');
		$this->load->view('templates/footer_new');
	}
	public function add_ban () {
		if (!$this->auth_model->is_logged_in()) {
			show_404();
		}
		if (!$this->auth_model->is_admin()) {
			show_404();
		}
		if ($this->admin_model->add_ban()) {
			$this->session->set_flashdata('messages', array('status' => 'success', 'message' => 'User has been banned!'));
			redirect('admin/manage_bans');
		} else {
			$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'User has not been banned!'));
			redirect('admin/manage_bans');
		}
	}
	public function remove_ban ($user_id) {
		if (!$this->auth_model->is_logged_in()) {
			show_404();
		}
		if (!$this->auth_model->is_admin()) {
			show_404();
		}
		if ($this->admin_model->remove_ban($user_id)) {
			$this->session->set_flashdata('messages', array('status' => 'success', 'message' => 'User has been unbanned!'));
			redirect('admin/manage_bans');
		} else {
			$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'User has not been unbanned!'));
			redirect('admin/manage_bans');
		}
	}
}