<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
	public function username_check($str) {
		return ctype_alnum($str);
	}
	public function index() {
		if (!$this->auth_model->is_logged_in()) {
			redirect('auth/login');
		} else {
			redirect('');
		}
	}
	public function login() {
		if ($this->auth_model->is_logged_in()) {
			redirect('');
		}

		$data['title'] = 'Login';

		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		if ($this->form_validation->run()) {
			$data['login_response'] = $this->auth_model->check_login();
			if ($data['login_response']) {
				redirect('');
			}
		}

		//$this->load->view('templates/header_new', $data);
		$this->load->view('auth/login_new', $data);
		///$this->load->view('templates/footer_new');
	}
	public function signup() {
		if ($this->auth_model->is_logged_in()) {
			redirect('');
		}

		$data['title'] = 'Signup';

		$this->form_validation->set_rules('username', 'Username', 'required|min_length[3]|max_length[16]|is_unique[users.username]|callback_username_check', array('username_check' => 'The Username field can only contain a-z, A-Z & 0-9.'));
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]|matches[password2]');
		$this->form_validation->set_rules('password2', 'Password (again)', 'required');

		if ($this->form_validation->run()) {
			$data['signup_response'] = $this->auth_model->signup();
			if ($data['signup_response']) {
				redirect('auth/login');
			}
		}

		//$this->load->view('templates/header_new', $data);
		$this->load->view('auth/signup_new', $data);
		//$this->load->view('templates/footer_new');
	}
	public function logout() {
		if (!$this->session->user_id) {
			redirect('auth/login');
		}
		
		$this->session->sess_destroy();
		redirect('auth/login');
	}
}