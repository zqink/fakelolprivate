<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function index() {
		if (!$this->auth_model->is_logged_in()) {
			redirect('auth/login');
		}

		$data['title'] = 'Dashboard';
		$data['combo_groups'] = $this->dashboard_model->get_combo_groups();
		$data['user_data'] = $this->auth_model->get_userdata();
		$data['statistics'] = $this->dashboard_model->get_statistics();

		$this->load->view('templates/header_new', $data);
		$this->load->view('dashboard/index_new', $data);
		$this->load->view('templates/footer_new');
	}
	public function combogroup($group_id = FALSE) {
		if (!$this->auth_model->is_logged_in()) {
			redirect('auth/login');
		}

		if (!$group_id) {
			$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'Combo group not found!'));
			redirect('dashboard');
		}

		$data['combo_group'] = $this->dashboard_model->get_combo_groups($group_id);
		if (!$data['combo_group']) {
			$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'Combo group not found!'));
			redirect('dashboard');
		}

		$data['title'] = $data['combo_group']['name'];
		$data['combo_groups'] = $this->dashboard_model->get_combo_groups();
		$data['combolists'] = $this->dashboard_model->get_combolists($group_id);
		$data['user_data'] = $this->auth_model->get_userdata();

		$this->load->view('templates/header_new', $data);
		$this->load->view('dashboard/combogroup_new');
		$this->load->view('templates/footer_new');
	}
	public function renew() {
		if (!$this->auth_model->is_logged_in()) {
			redirect('auth/login');
		}

		$data['title'] = 'Renew Subscription';
		$data['combo_groups'] = $this->dashboard_model->get_combo_groups();
		$data['user_data'] = $this->auth_model->get_userdata();
		$data['shoppygg_products'] = $this->config->item('shoppygg_products');

		$this->form_validation->set_rules('key', 'Key', 'required');
		if ($this->form_validation->run()) {
			$data['renew_response'] = $this->dashboard_model->renew_sub();
			if ($data['renew_response']) {
				$this->session->set_flashdata('messages', array('status' => 'success', 'message' => 'Successfully renewed your subscription!'));
			} else {
				$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'Key not found or already used!'));
			}
		}

		$this->load->view('templates/header_new', $data);
		$this->load->view('dashboard/renew_new');
		$this->load->view('templates/footer_new');
	}
		public function proxies() {
		if (!$this->auth_model->is_logged_in()) {
			redirect('auth/login');
		}

		$data['title'] = 'Proxies';
		$data['combo_groups'] = $this->dashboard_model->get_combo_groups();
		$data['user_data'] = $this->auth_model->get_userdata();
		$data['shoppygg_products'] = $this->config->item('shoppygg_products');

		$this->form_validation->set_rules('key', 'Key', 'required');
		if ($this->form_validation->run()) {
			$data['renew_response'] = $this->dashboard_model->renew_sub();
			if ($data['renew_response']) {
				$this->session->set_flashdata('messages', array('status' => 'success', 'message' => 'Successfully renewed your subscription!'));
			} else {
				$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'Key not found or already used!'));
			}
		}

		$this->load->view('templates/header_new', $data);
		$this->load->view('dashboard/proxies');
		$this->load->view('templates/footer_new');
	}

	public function download_combo($combo_id = FALSE) {
		if (!$this->auth_model->is_logged_in()) {
			redirect('auth/login');
		}

		$data['user_data'] = $this->auth_model->get_userdata();
		if ($data['user_data']['user_group'] == -1) {
			$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'Sorry, you have been banned! Contact an administrator!'));
			redirect('dashboard');
		}
		if (!$data['user_data']['sub_active']) {
			$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'Sorry, you have no active subscription!'));
			redirect('dashboard');
		}
		if ($data['user_data']['downloads_left'] < 1) {
			$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'Sorry, you have reached the maximum downloads for today!'));
			redirect('dashboard');
		}

		$data['combolist'] = $this->dashboard_model->get_combolist($combo_id);
		if (!$data['combolist']) {
			$this->session->set_flashdata('messages', array('status' => 'error', 'message' => 'Combolist not found!'));
			redirect('dashboard');
		}

		$this->dashboard_model->add_download($combo_id);
		
		$this->output->set_header("Content-type: text/plain");
		$this->output->set_header("Content-Disposition: attachment; filename=".url_title($data['combolist']['name'])."_#".$data['combolist']['id'].".txt");
		$this->output->set_output($data['combolist']['content']);
	}
}