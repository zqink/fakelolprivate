<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function index() {
		$data['title'] = 'Home';
		if ($this->auth_model->is_logged_in()) {
			redirect('dashboard');
		}

		$data['statistics'] = $this->dashboard_model->get_statistics();

		//$this->load->view('templates/header_new', $data);
		$this->load->view('home/index_new', $data);
		//$this->load->view('templates/footer_new');
    }
}