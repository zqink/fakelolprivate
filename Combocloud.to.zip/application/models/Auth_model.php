<?php
	class Auth_model extends CI_Model {
		public function __construct() {
			$this->load->database();
		}
		
		public function check_login() {
			$query = $this->db->get_where('users', array('username' => $this->input->post('username')));
			$user_details = $query->row_array();
			if ($user_details) {
				if (password_verify($this->input->post('password'), $user_details['password'])) {
		            $sessionArray = array(
		            	'user_id' => $user_details['id']
		            );
					$this->session->set_userdata($sessionArray);
					$this->session->set_flashdata('messages', array('status' => 'success', 'message' => 'You\'ve been logged in!'));
					return true;
				} else {
					$this->session->set_flashdata('messages', array('status' => 'danger', 'message' => 'Login failed!'));
					return false;
				}
			} else {
				$this->session->set_flashdata('messages', array('status' => 'danger', 'message' => 'Login failed!'));
				return false;
			}
		}

		public function signup() {
			$data = array(
				'username' => $this->input->post('username'),
				'email' => $this->input->post('email'),
				'password' => password_hash($this->input->post('password'),PASSWORD_DEFAULT),
				'sub_active_till' => time()-1,
				'user_group' => 0,
			);
			$result = $this->db->insert('users', $data);
			$this->session->set_flashdata('messages', array('status' => 'success', 'message' => 'Signup successfull, you can now login!'));
		}

		public function is_logged_in () {
			if ($this->session->user_id) {
				return true;
			} else {
				return false;
			}
		}

		public function get_userdata() {
			$query = $this->db->get_where('users', array('id' => $this->session->user_id));
			$userdata = $query->row_array();

			if ($userdata['sub_active_till'] > time()) {
				$userdata['sub_active'] = true;
				$userdata['downloads_left'] = $this->dashboard_model->downloads_left();
			} else {
				$userdata['sub_active'] = false;
			}
			$userdata['amount_lists_downloaded'] = $this->dashboard_model->get_amountofmydownloads();

			return $userdata;
		}

		public function is_admin() {
			if ($this->auth_model->get_userdata()['user_group'] == 1) {
				return true;
			} else {
				return false;
			}
		}
	}