<?php
	class Dashboard_model extends CI_Model {
		public function __construct() {
			$this->load->database();
		}
		public function get_combo_groups($id = FALSE) {
			if ($id) {
				$query = $this->db->get_where('groups', array('id' => $id));
				return $query->row_array();
			} else {
				$query = $this->db->get('groups');
				return $query->result_array();
			}
		}
		public function get_all_combolists() {
			$this->db->select('id, name, amount_lines, created_timestamp, alpha2_code');
			$query = $this->db->get('combolists');
			return $query->result_array();
		}
		public function get_combolists($id) {
			$this->db->select('id, name, amount_lines, created_timestamp, alpha2_code');
			$query = $this->db->get_where('combolists', array('group_id' => $id));
			return $query->result_array();
		}
		public function get_combolist($id) {
			$query = $this->db->get_where('combolists', array('id' => $id));
			return $query->row_array();
		}
		public function downloads_left() {
			$query = $this->db->get_where('downloads', array('user_id' => $this->session->user_id, 'date_downloaded' => date("Y-m-d")));
			return $this->config->item('sub_downloads_per_day')-$query->num_rows();
		}
		public function check_if_downloaded($combolist_id) {
			$query = $this->db->get_where('downloads', array('combolist_id' => $combolist_id, 'user_id' => $this->session->user_id));
			return $query->row_array();
		}
		public function add_download($combolist_id) {
			$data = array(
				'user_id' => $this->session->user_id,
				'combolist_id' => $combolist_id,
				'date_downloaded' => date("Y-m-d"),
			);
			$result = $this->db->insert('downloads', $data);
		}
		public function renew_sub () {
			$query = $this->db->get_where('subscription_keys', array('key_content' => $this->input->post('key')));
			$key_data = $query->row_array();

			if ($key_data) {
				$userdata = $this->auth_model->get_userdata();
				if ($userdata['sub_active']) {
					$data = array(
						'sub_active_till' => $userdata['sub_active_till']+($key_data['time_valid']*60*60*24),
					);

					$this->db->where('id', $userdata['id']);
					$this->db->update('users', $data);
				} else {
					$data = array(
						'sub_active_till' => time()+($key_data['time_valid']*60*60*24),
					);

					$this->db->where('id', $userdata['id']);
					$this->db->update('users', $data);
				}

				$data = array(
					'content' => $key_data['key_content'],
					'time_valid' => $key_data['time_valid'],
					'used_by_user_id' => $userdata['id'],
				);
				$result = $this->db->insert('subscription_keys_used', $data);

				$this->db->where('id', $key_data['id']);
				$this->db->delete('subscription_keys');

				return true;
			}
		}
		public function get_statistics () {
			$this->db->select_sum('amount_lines');
			$query = $this->db->get('groups');
			$result['amount_lines'] = $query->row_array()['amount_lines'];

			$this->db->select_sum('amount_combos');
			$query = $this->db->get('groups');
			$result['amount_combolists'] = $query->row_array()['amount_combos'];

			$query = $this->db->get('users');
			$result['amount_users'] = $query->num_rows();

			$result['days_online'] = round((time() - strtotime($this->config->item('online_since')))/(60 * 60 * 24));

			return $result;
		}

		// CUSTOM
		public function get_amountofmydownloads() {
			$query = $this->db->get_where('downloads', array('user_id' => $this->session->user_id));
			return $query->num_rows();
		}
		public function get_recentlists() {
			$this->db->select('id, name, amount_lines, group_id, created_timestamp');
			$this->db->order_by("id", "DESC");
			$this->db->limit(5);
			$query = $this->db->get('combolists');
			return $query->result_array();
		}
	}