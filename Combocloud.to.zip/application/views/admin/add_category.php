
    <div class="container" style="margin-top: 2em;">
      <div class="row">
        <div class="col-lg-12">
          <div class="card text-white bg-primary mb-3">
            <div class="card-header">Add Group</div>
             <div class="card-body">
              <?php echo form_open_multipart('admin/add_category');?>
                <div class="form-group">
                  <label>Group Name:</label>
                  <input type="text" class="form-control" name="name" placeholder="Gaming">
                </div>
                <div class="form-group">
                <input type="submit" class="btn btn-success" value="add" />
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>