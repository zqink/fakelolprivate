
        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->
        <div class="wrapper">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <h4 class="page-title"><?= $title; ?></h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
				<div class="row">
                    <div class="col-md-12">
                        <div class="card card-body">
                            <h4 class="card-title">Add Group</h4>
              <?php echo form_open_multipart('admin/add_category');?>
                <div class="form-group">
                  <label>Group Name:</label>
                  <input type="text" class="form-control" name="name" placeholder="Gaming">
                </div>
                <div class="form-group">
                <input type="submit" class="btn btn-success" value="add" />
                </div>
              </form>
                        </div>
                    </div>
                <!-- end row -->       

            </div>
            <!-- end container -->
        </div>
        <!-- end wrapper -->

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->