
    <div class="container" style="margin-top: 2em;">
      <div class="row">
    		<div class="col-lg-12">
    			<div class="card text-white bg-primary mb-3">
                    <div class="card-header">Add Combo</div>
                  	<div class="card-body">
						<?php echo form_open_multipart('admin/add_combo');?>
						  <div class="form-group">
						    <label>Name:</label>
						    <input type="text" class="form-control" name="name" placeholder="example.com">
						  </div>
						  <div class="form-group">
						    <label>Group:</label>
						    <select class="form-control" name="group">
						      <option>Please select...</option>
		                      <?php foreach ($combo_groups as $combo_group): ?><option value="<?= $combo_group['id']; ?>"><?= $combo_group['name']; ?></option><?php endforeach; ?>
		                    </select>
						  </div>
						  <div class="form-group">
						    <label>File:</label>
							<p><input type="file" name="userfile" size="20" /></p>
						  </div>
						  <div class="form-group">
							<input type="submit" class="btn btn-success" value="upload" />
						  </div>
						</form>
                    </div>
                </div>
            </div>
      </div>
    </div>
</div>