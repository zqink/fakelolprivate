
    <div class="container" style="margin-top: 2em;">
      <div class="row">
        <div class="col-lg-12">
          <div class="card text-white bg-primary mb-3">
            <div class="card-header">Delete Combo</div>
            <div class="card-body">
              <?php echo form_open_multipart('admin/delete_category');?>
                <div class="form-group">
                  <label>Group:</label>
                  <select class="form-control" name="group">
                    <option>Select Group...</option>
                    <?php foreach ($combo_groups as $combo_group): ?><option value="<?= $combo_group['id']; ?>"><?= $combo_group['name']; ?> (#<?= $combo_group['id']; ?>)</option><?php endforeach; ?>
                  </select>
                </div>
                <div class="form-group">
                  <input type="submit" class="btn btn-success" value="delete" />
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>