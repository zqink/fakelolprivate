
        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->
        <div class="wrapper">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <h4 class="page-title"><?= $title; ?></h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
				<div class="row">
                    <div class="col-md-12">
                        <div class="card card-body">
                            <h4 class="card-title">Delete Group</h4>
              <?php echo form_open_multipart('admin/delete_category');?>
                <div class="form-group">
                  <label>Group:</label>
                  <select class="form-control" name="group">
                    <option>Select Group...</option>
                    <?php foreach ($combo_groups as $combo_group): ?><option value="<?= $combo_group['id']; ?>"><?= $combo_group['name']; ?> (#<?= $combo_group['id']; ?>)</option><?php endforeach; ?>
                  </select>
                </div>
                <div class="form-group">
                  <input type="submit" class="btn btn-success" value="delete" />
                </div>
              </form>
                        </div>
                    </div>
                <!-- end row -->       

            </div>
            <!-- end container -->
        </div>
        <!-- end wrapper -->

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->