
    <div class="container" style="margin-top: 2em;">
      <div class="row">
        <div class="col-lg-12">
          <div class="card text-white bg-primary mb-3">
            <div class="card-header">Delete Combo</div>
            <div class="card-body">
              <?php echo form_open_multipart('admin/delete_combo');?>
                <div class="form-group">
                  <label>Combo:</label>
                  <select class="form-control" name="combo">
                    <option>Select Combo...</option>
                    <?php foreach ($combolists as $combolist): ?><option value="<?= $combolist['id']; ?>"><?= $combolist['name']; ?> (#<?= $combolist['id']; ?>)</option><?php endforeach; ?>
                  </select>
                </div>
                <div class="form-group">
                  <input type="submit" class="btn btn-success" value="delete" />
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>