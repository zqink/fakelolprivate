
        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->
        <div class="wrapper">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <h4 class="page-title"><?= $title; ?></h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
				<div class="row">
                    <div class="col-md-12">
                        <div class="card card-body">
                            <h4 class="card-title">Delete Combo</h4>
              <?php echo form_open_multipart('admin/delete_combo');?>
                <div class="form-group">
                  <label>Combo:</label>
                  <select class="form-control" name="combo">
                    <option>Select Combo...</option>
                    <?php foreach ($combolists as $combolist): ?><option value="<?= $combolist['id']; ?>"><?= $combolist['name']; ?> (#<?= $combolist['id']; ?>)</option><?php endforeach; ?>
                  </select>
                </div>
                <div class="form-group">
                  <input type="submit" class="btn btn-success" value="delete" />
                </div>
              </form>
                        </div>
                    </div>
                <!-- end row -->       

            </div>
            <!-- end container -->
        </div>
        <!-- end wrapper -->

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->