
    <div class="container" style="margin-top: 2em;">
      <div class="row">
    		<div class="col-lg-12">
    			<div class="card text-white bg-primary mb-3">
                    <div class="card-header">Edit Category</div>
                  	<div class="card-body">
                  		<p>Test</p>
                    </div>
                </div>
            </div>
      </div>
    </div>
</div>