
    <div class="container" style="margin-top: 2em;">
      <div class="row">
    		<div class="col-lg-12">
    			<div class="card text-white bg-primary mb-3">
                    <div class="card-header">Statistics</div>
                  	<div class="card-body">
						<table class="table table-primary">
						  <tbody>
						    <tr class="table-active">
						      <td>Users</td>
						      <td><?= $statistics['amount_users']; ?></td>
						    </tr>
						    <tr class="table-active">
						      <td>Total Combolists</td>
						      <td><?= $statistics['amount_combolists']; ?></td>
						    </tr>
						    <tr class="table-active">
						      <td>Total Lines</td>
						      <td><?= $statistics['amount_lines']; ?></td>
						    </tr>
						  </tbody>
						</table>
                    </div>
                </div>
            </div>
      </div>
    </div>
</div>