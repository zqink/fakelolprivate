
        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->
        <div class="wrapper">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <h4 class="page-title"><?= $title; ?></h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
				<div class="row">
                    <div class="col-md-12">
                        <div class="card card-body">
                            <h4 class="card-title">Statistics</h4>
							<table class="table">
							  <tbody>
							    <tr class="table-active">
							      <td>Users</td>
							      <td><?= $statistics['amount_users']; ?></td>
							    </tr>
							    <tr class="table-active">
							      <td>Total Combolists</td>
							      <td><?= $statistics['amount_combolists']; ?></td>
							    </tr>
							    <tr class="table-active">
							      <td>Total Lines</td>
							      <td><?= $statistics['amount_lines']; ?></td>
							    </tr>
							  </tbody>
							</table>
                        </div>
                    </div>
                <!-- end row -->       

            </div>
            <!-- end container -->
        </div>
        <!-- end wrapper -->

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->