
    <div class="container" style="margin-top: 2em;">
      <div class="row">
    		<div class="col-lg-12">
    			<div class="card text-white bg-primary mb-3">
            <div class="card-header">Generate Keys</div>
            <div class="card-body">
              <?php if (isset($add_key_response) && $add_key_response): ?>
                <div class="form-group">
                  <label>Generated Keys</label>
                  <textarea class="form-control" rows="10"><?php foreach ($add_key_response as $key): ?><?= $key. PHP_EOL; ?><?php endforeach; ?></textarea>
                </div>
              <?php else: ?>
              <?= form_open('admin/key_generator'); ?>
                <div class="form-group">
                  <label>Amount</label>
                  <input type="number" class="form-control" placeholder="100" name="amount">
                </div>
                <div class="form-group">
                  <label>Days Valid</label>
                  <input type="number" class="form-control" placeholder="7" name="days_valid">
                </div>
                <button type="submit" class="btn btn-success">Submit</button>
              </form>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>