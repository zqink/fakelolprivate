
        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->
        <div class="wrapper">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <h4 class="page-title"><?= $title; ?></h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
				<div class="row">
                    <div class="col-md-12">
                        <div class="card card-body">
                            <h4 class="card-title">Generate Keys</h4>
              <?php if (isset($add_key_response) && $add_key_response): ?>
                <div class="form-group">
                  <label>Generated Keys</label>
                  <textarea class="form-control" rows="10"><?php foreach ($add_key_response as $key): ?><?= $key. PHP_EOL; ?><?php endforeach; ?></textarea>
                </div>
              <?php else: ?>
              <?= form_open('admin/key_generator'); ?>
                <div class="form-group">
                  <label>Amount</label>
                  <input type="number" class="form-control" placeholder="100" name="amount">
                </div>
                <div class="form-group">
                  <label>Days Valid</label>
                  <input type="number" class="form-control" placeholder="7" name="days_valid">
                </div>
                <button type="submit" class="btn btn-success">Submit</button>
              </form>
              <?php endif; ?>
                        </div>
                    </div>
                <!-- end row -->       

            </div>
            <!-- end container -->
        </div>
        <!-- end wrapper -->

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->