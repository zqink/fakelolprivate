
    <div class="container" style="margin-top: 2em;">
      <div class="row">
        <div class="col-lg-6">
          <div class="card text-white bg-primary mb-3">
            <div class="card-header">Ban</div>
            <div class="card-body">
              <?= form_open('admin/add_ban'); ?>
                <div class="form-group">
                  <label>Username</label>
				  <select class="form-control" name="ban_username">
				    <option>Please select...</option>
		            <?php foreach ($banable_members as $banable_member): ?><option value="<?= $banable_member['username']; ?>"><?= $banable_member['username']; ?></option><?php endforeach; ?>
		          </select>
                </div>
                <button type="submit" class="btn btn-success">Submit</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="card text-white bg-primary mb-3">
            <div class="card-header">Unban</div>
            <div class="card-body">
              <p>
              	<?php foreach ($banned_members as $banned_member): ?>
              		<?= $banned_member['username']; ?> | <a href="<?= base_url(); ?>admin/remove_ban/<?= $banned_member['id']; ?>">UNBAN</a><br>
              	<?php endforeach; ?>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>