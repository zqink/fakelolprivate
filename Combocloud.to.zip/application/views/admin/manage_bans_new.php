
        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->
        <div class="wrapper">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <h4 class="page-title"><?= $title; ?></h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
				<div class="row">
                    <div class="col-md-6">
                        <div class="card card-body">
                            <h4 class="card-title">Ban User</h4>
              <?= form_open('admin/add_ban'); ?>
                <div class="form-group">
                  <label>Username</label>
				  <select class="form-control" name="ban_username">
				    <option>Please select...</option>
		            <?php foreach ($banable_members as $banable_member): ?><option value="<?= $banable_member['username']; ?>"><?= $banable_member['username']; ?></option><?php endforeach; ?>
		          </select>
                </div>
                <button type="submit" class="btn btn-success">Submit</button>
              </form>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card card-body">
                            <h4 class="card-title">Unban User</h4>
              <p>
              	<?php foreach ($banned_members as $banned_member): ?>
              		<?= $banned_member['username']; ?> | <a href="<?= base_url(); ?>admin/remove_ban/<?= $banned_member['id']; ?>">UNBAN</a><br>
              	<?php endforeach; ?>
              </p>
                        </div>
                    </div>
                <!-- end row -->       

            </div>
            <!-- end container -->
        </div>
        <!-- end wrapper -->

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->