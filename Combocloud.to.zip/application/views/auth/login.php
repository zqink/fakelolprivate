
		<div class="container" style="margin-top: 2em;">
			<div class="row">
			   <div class="col-lg-12">
	              <div class="card text-white bg-primary">
	                <div class="card-header"><?= $title; ?></div>
	                <div class="card-body">
						<?= form_open('auth/login'); ?>
						  <div class="form-group">
						    <label>Username</label>
						    <input type="text" class="form-control" placeholder="Username" name="username">
						  </div>
						  <div class="form-group">
						    <label>Password</label>
						    <input type="password" class="form-control" placeholder="Password" name="password">
						  </div>
						  <button type="submit" class="btn btn-secondary">Login</button>
						</form>
	                </div>
	              </div>
	           </div>
	        </div>
		</div>