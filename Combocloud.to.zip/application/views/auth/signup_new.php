
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Responsive Admin Dashboard Template">
        <meta name="keywords" content="admin,dashboard">
        <meta name="author" content="stacks">
        <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        
        <script src="<?= base_url(); ?>assets/cdn-cgi/apps/head/h94fYuDBsvPuE9sn3pL-FNtjmPY.js"></script><link rel="apple-touch-icon" sizes="180x180" href="<?= base_url(); ?>assets/assets/images/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url(); ?>assets/assets/images/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url(); ?>assets/assets/images/favicon-16x16.png">
        
        <!-- Title -->
        <title>Register - Combocloud</title>

        <!-- Styles -->
        <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900&amp;display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="<?= base_url(); ?>assets/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?= base_url(); ?>assets/assets/plugins/font-awesome/css/all.min.css" rel="stylesheet">
      
        <!-- Theme Styles -->
        <link href="<?= base_url(); ?>assets/assets/css/lime.min.css" rel="stylesheet">
        <link href="<?= base_url(); ?>assets/assets/css/themes/admin2.css" rel="stylesheet">
        <link href="<?= base_url(); ?>assets/assets/css/custom.css" rel="stylesheet">

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
        <style>
.login-page {
    background: none !important;
    background-color: #242935 !important;
}
.login-page::before {
background: none !important;
}
</style>

    </head>
    <body class="login-page err-500">
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="container">
            <div class="login-container">
                <div class="row">
                    <div class="col-lg-4 col-md-5 col-sm-9 lfh">
                        <div class="card login-box">
                            <div class="card-body">
                                <h5 class="card-title">Register</h5>
                                <form action="<?= base_url(); ?>auth/signup" method="post" accept-charset="utf-8">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Username" name="username">
                                    </div>
                                    <div class="form-group">
                                        <input type="email" class="form-control" placeholder="E-Mail" name="email">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Password" name="password">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Repeat password" name="password2">
                                    </div>
									
                                    <button type="submit" class="btn btn-info btn-block" style=" margin-top: 13px; ">Sign Up</button>
                                </form><br>
                                <p style="text-align: center;margin-bottom: -3px;">Already have an account? <a href="<?= base_url(); ?>auth/login" "font-weight-medium text-primary" href="<?= base_url(); ?>auth/signup" forgot-link> Login now </a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        
        
        <!-- Javascripts -->
        <script src="<?= base_url(); ?>assets/assets/plugins/jquery/jquery-3.1.0.min.js"></script>
        <script src="<?= base_url(); ?>assets/assets/plugins/bootstrap/popper.min.js"></script>
        <script src="<?= base_url(); ?>assets/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?= base_url(); ?>assets/assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
        <script src="<?= base_url(); ?>assets/assets/js/lime.min.js"></script>

        <!-- Bootstrap Notify -->
        <script src="<?= base_url(); ?>assets/assets/js/bootstrap-notify.min.js"></script>
                    <script type="text/javascript">
                        $(document).ready(function(){
                            //Welcome Message (not for login page)
                            function notify(message, type){
                                $.notify({
                                    message: message
                                },{
                                    type: type,
                                    allow_dismiss: false,
                                    label: 'Cancel',
                                    placement: {
                                        from: 'bottom',
                                        align: 'left'
                                    },
                                    delay: 2500,
                                    animate: {
                                            enter: 'animated fadeInUp',
                                            exit: 'animated fadeOutDown'
                                    },
                                    offset: {
                                        x: 30,
                                        y: 30
                                    }
                                });
                            }
             <?php if (count($this->session->flashdata()) != 0): ?>
                  <?php foreach($this->session->flashdata() as $message): ?>
                                                                                                notify('<?= $message['message']; ?>', '<?= $message['status']; ?>');
																								                  <?php endforeach; ?>
              <?php endif; ?>
                                                                                                                });
                    </script>
    </body>
</html>