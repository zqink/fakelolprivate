                <div class="lime-container">
            <div class="lime-body">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                           
                            <div class="page-title">
                                <h3><?= $title; ?></h3>
                            </div>
                            
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Combolists</h5>
                                    <p>Browse through this groups combolists.</p>
                                    <table class="table" id="example">
                                        <thead>
                                            <tr>
								                <th>#</th>
								                <th>Name</th>
                                                <th>Country</th>
								                <th>Lines</th>
                                                <th>Published</th>
								                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										 <?php foreach ($combolists as $recent_combolist): ?>
																			            <tr>
										                <td><?= $recent_combolist['id']; ?></td>
										                <td><?= $recent_combolist['name']; ?></td>
                                                        <td><img src="https://combocloud.to/assets/images/country_flags/world.png" style="width: 20px;"> <span style="display: none;">country:world</span></td>
										                <td><?= number_format($recent_combolist['amount_lines'], 0, ',', '.'); ?></td>
                                                        <td><?= date("d M Y", $recent_combolist['created_timestamp']); ?></td>
										                <td><a class="btn btn-secondary btn-sm" href="<?= base_url(); ?>dashboard/download_combo/<?= $recent_combolist['id']; ?>">Download </a></td>
										            </tr>
													 <?php endforeach; ?>
													</tbody>