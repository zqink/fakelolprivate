
    <div class="container" style="margin-top: 2em;">
      <div class="row">
    		<div class="col-lg-12">
    			<div class="card text-white bg-primary mb-3">
                    <div class="card-header">Your Account</div>
                  	<div class="card-body">
                    	<p class="card-text">Welcome to our dashboard, <?= $user_data['username']; ?>.</p>
                    	<?php if($user_data['sub_active']): ?>
                    	<p class="card-text" style="color: green;">Your subscription is valid for <?= timespan(time(), $user_data['sub_active_till'], 4); ?>.</p>
                    	<p>You've <?= $user_data['downloads_left']; ?> downloads left for today.</p>
                    	<?php else: ?>
                    	<p class="card-text" style="color: orange;">Your subscription expired, please <a href="<?= base_url(); ?>dashboard/renew">renew it</a> in order to download combos.</p>
                    	<?php endif; ?>
                    </div>
                </div>
            </div>
    			<div class="col-lg-12">
    			  <div class="card text-white bg-primary mb-3">
                    <div class="card-header">Combo Groups</div>
                  	<div class="card-body">
						<table class="table table-primary">
						  <thead style="border: 0px;">
						    <tr align="center">
						      <th style="border-top: 0px; width: 10%;" scope="col">Group</th>
						      <th style="border-top: 0px; width: 25%;" scope="col">Combos</th>
						      <th style="border-top: 0px; width: 35%;" scope="col">Lines</th>
						      <th style="border-top: 0px; width: 20%;" scope="col"></th>
						    </tr>
						  </thead>
						  <tbody>
						  	<?php if (isset($combo_groups)): ?>
						  	<?php foreach ($combo_groups as $combo_group): ?>
						    <tr align="center">
						      <td><?= $combo_group['name']; ?></td>
						      <td><?= $combo_group['amount_combos']; ?></td>
						      <td><?= $combo_group['amount_lines']; ?></td>
						      <td><a class="btn btn-outline-secondary" href="<?= base_url(); ?>dashboard/combogroup/<?= $combo_group['id']; ?>">View</a></td>
						    </tr>
							<?php endforeach; ?>
							<?php else: ?>
						    <tr align="center">
						      <td>No groups yet.</td>
						      <td></td>
						      <td></td>
						      <td></td>
						    </tr>
							<?php endif; ?>
						  </tbody>
						</table>
                  </div>
            </div>
        </div>
    </div>
	</div>