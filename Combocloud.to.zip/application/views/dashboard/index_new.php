                <div class="lime-container">
            <div class="lime-body">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                                  
                            <div class="page-title">
                                <h3>Dashboard</h3>
                            </div>
                            
                        </div>
                    </div>
					<div class="row">
                        <div class="col-md-12">
                            <div class="card bg-info text-white">
                                <div class="card-body">
                                    <div class="dashboard-info row">
                                        <div class="info-text col-md-8">
                                            <h5 class="card-title">Welcome <?= $user_data['username']; ?></h5>
						                                                                <p>This is our dashboard, follow these three steps to get started:</p>
                                            <ul>
                                                <li>Purchase your subscription <a style="color:#052b54;" href="<?= base_url(); ?>dashboard/renew">here</a>.</li>
                                                <li>Browse through our combo groups.</li>
                                                <li>Download the lists from the groups you want.</li>
                                                
                                            </ul>
                                            <br>
                                            <a href="https://discord.gg/cvVzpcJ" target="_blank" class="btn btn-info active" role="button" aria-pressed="true"><i class="fab fa-discord"></i> &nbsp; Join our Discord server</a>
						                                                            </div>
                                        <div class="upgrade-image col-md-4"></div>
                                    </div>
                                </div>
                            </div>
                        </div>                      
                    </div>
                    <div class="row">
                        <div class="col-xl">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Categories</h5>
                                    <p>Browse through our Categories. To download you need an active subscription.</p>
                                    <table class="table">
                                        <thead>
                                            <tr>
										      <th scope="col">Name</th>
										      <th scope="col">Databases</th>
										      <th scope="col">Total Lines</th>
										      <th scope="col"></th>
                                            </tr>
                                        </thead>
                                        <tbody>

								<?php foreach ($combo_groups as $combo_group): ?>
																			  											    <tr>
										      <td>
                                                <div class="row">
                                                   <div class="col-md-11">
                                                        <?= $combo_group['name']; ?>                                                    </div>
                                                    
                                                </div>
                                              </td>
										      <td><?= $combo_group['amount_combos']; ?></td>
										      <td><?= $combo_group['amount_lines']; ?></td>
										      <td><a class="btn btn-outline-secondary" href="<?= base_url(); ?>dashboard/combogroup/<?= $combo_group['id']; ?>">View</a></td>
										    </tr>
											<?php endforeach; ?>
																						                                        </tbody>
                                    </table>             
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>