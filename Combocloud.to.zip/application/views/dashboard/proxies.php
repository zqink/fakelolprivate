        <div class="lime-container">
            <div class="lime-body">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                       
                                    
                            <div class="page-title">
                                
                                <h3>Proxies</h3>
                                
                            </div>
                    
                        </div>
                    </div>
                    
      <div class="row">
    		<div class="col-lg-4">
	            <div class="card">
	            	<img src="https://i.imgur.com/uoTKxXx.png" class="card-img-top" alt="Placeholder"><center>
				        <div class="card-body">
				    	    <h5 class="card-title">Fresh Http/s proxies<br><br>
								<small>Updating every 5-10 minutes</small>
							</h5>
							    <a href="https://combocloud.to//dashboard/proxies/https" class="btn btn-info btn-block" role="button" aria-pressed="true">
								    <i class="fas fa-download"></i> &nbsp; Download
						    	</a>
						</div>
					</center>
				</div>
			</div>
    		<div class="col-lg-4">
	            <div class="card">
	            	<img src="https://i.imgur.com/C5tnBl9.png" class="card-img-top" alt="Placeholder"><center>
				        <div class="card-body">
				    	    <h5 class="card-title">Fresh Socks4 proxies<br><br>
								<small>Updating every 5-10 minutes</small>
							</h5>
							    <a href="https://combocloud.to//dashboard/proxies/socks4" class="btn btn-info btn-block" role="button" aria-pressed="true">
								    <i class="fas fa-download"></i> &nbsp; Download
						    	</a>
						</div>
					</center>
				</div>
			</div>
    		<div class="col-lg-4">
	            <div class="card">
	            	<img src="https://i.imgur.com/tRQQE4m.png" class="card-img-top" alt="Placeholder"><center>
				        <div class="card-body">
				    	    <h5 class="card-title">Fresh Socks4 proxies<br><br>
								<small>Updating every 5-10 minutes</small>
							</h5>
							    <a href="https://combocloud.to//dashboard/proxies/socks5" class="btn btn-info btn-block" role="button" aria-pressed="true">
								    <i class="fas fa-download"></i> &nbsp; Download
						    	</a>
						</div>
					</center>
				
				</div>
			</div>
        </div>
    </div>
	</div>