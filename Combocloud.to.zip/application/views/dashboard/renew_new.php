                <div class="lime-container">
            <div class="lime-body">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                       
                            
                            <div class="page-title">
                                <h3>Purchase Subscription</h3>
                            </div>
                           
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-body">
						<?= form_open('dashboard/renew'); ?>
									  <div class="form-group">
									    <label>Redeem key</label>
									    <input type="text" class="form-control" placeholder="XXXXX-XXXXX-XXXXX-XXXXX" name="key">
									  </div>
									  <button type="submit" class="btn btn-info btn-block">Redeem</button>
									</form>     
                                </div>
                            </div>
                        </div>
                    </div>
                    <center>
                           <div class="alert alert-info" role="alert">
                                        <strong>GET 25% OFF LIFETIME PLAN!</strong> Use coupon: <mark>LIFETIME</mark>
                                    </div>
                       </center><br>
                    <div class="row">
                        <div class="col">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                                                                <div class="col-12 col-sm-12 col-md-3">
                                            <ul class="pricing">
                                                <li>
                                                    <h1>1 DAY</h1>
                                                </li>
                                                <li>Full Access</li>
                                                <li>30 Downloads per day</li>
                                                <li>Access to the "unlimited" section</li>
                                                <li>Access to our free proxies</li>
                                                <li>24/7 Support</li>
                                                <li>
                                                    <h3 style="margin-top:0;">€6.99</h3>
                                                </li>
                                                <li>
                                                    <button data-sellix-product="5eab6f2203a18" type="button" class="btn btn-info btn-block">Purchase</button>
                                                </li>
                                            </ul>
                                        </div>
                                                                                <div class="col-12 col-sm-12 col-md-3">
                                            <ul class="pricing">
                                                <li>
                                                    <h1>1 WEEK</h1>
                                                </li>
                                                <li>Full Access</li>
                                                <li>30 Downloads per day</li>
                                                <li>Access to the "unlimited" section</li>
                                                <li>Access to our free proxies</li>
                                                <li>24/7 Support</li>
                                                <li>
                                                    <h3 style="margin-top:0;">€16.99</h3>
                                                </li>
                                                <li>
                                                    <button data-sellix-product="5eab6ec1259bd" type="button" class="btn btn-info btn-block">Purchase</button>
                                                </li>
                                            </ul>
                                        </div>
                                                                                <div class="col-12 col-sm-12 col-md-3">
                                            <ul class="pricing">
                                                <li>
                                                    <h1>1 MONTH</h1>
                                                </li>
                                                <li>Full Access</li>
                                                <li>30 Downloads per day</li>
                                                <li>Access to the "unlimited" section</li>
                                                <li>Access to our free proxies</li>
                                                <li>24/7 Support</li>
                                                <li>
                                                    <h3 style="margin-top:0;">€49.99</h3>
                                                </li>
                                                <li>
                                                    <button data-sellix-product="5eab6ecf71954" type="button" class="btn btn-info btn-block">Purchase</button>
                                                </li>
                                            </ul>
                                        </div>
                                                                                <div class="col-12 col-sm-12 col-md-3">
                                            <ul class="pricing">
                                                <li>
                                                    <h1>LIFETIME</h1>
                                                </li>
                                                <li>Full Access</li>
                                                <li>30 Downloads per day</li>
                                                <li>Access to the "unlimited" section</li>
                                                <li>Access to our free proxies</li>
                                                <li>24/7 Support</li>
                                                <li>
                                                    <h3 style="margin-top:0;">€249.99</h3>
                                                </li>
                                                <li>
                                                    <button data-sellix-product="5ec583ecd9a94" type="button" class="btn btn-info btn-block">Purchase</button>
                                                </li>
                                            </ul>
                                        </div>
                                                                            </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>