
    <div class="container" style="margin-top: 2em;">
      <div class="row">
    			<div class="col-lg-12">
    			  <div class="card text-white bg-primary mb-3">
                    <div class="card-header">Welcome to <?= $this->config->item('website_name'); ?></div>
                    <div class="card-body">
                      <p class="card-text">
                        <b>About us:</b><br>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.<br>
                        <br>
                        <b>Our Stats:</b><br>
                        Users: <?= $statistics['amount_users']; ?><br>
                        Total Combolists: <?= $statistics['amount_combolists']; ?><br>
                        Total Lines: <?= $statistics['amount_lines']; ?><br>
                      </p>
                    </div>
                  </div>
            </div>
        </div>
    </div>
	</div>