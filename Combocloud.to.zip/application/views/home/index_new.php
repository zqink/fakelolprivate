<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Combocloud is a cloud based combo and database provider, the place to find the best combos and databases for all of your needs.">
        <meta name="keywords" content="Combocloud, Priv8.to">
        <meta name="author" content="Combocloud.to">
        <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <script src="<?= base_url(); ?>assets/cdn-cgi/apps/head/h94fyudbsvpue9sn3pl-fntjmpy.js"></script><link rel="apple-touch-icon" sizes="180x180" href="<?= base_url(); ?>assets/assets/images/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url(); ?>assets/assets/images/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url(); ?>assets/assets/images/favicon-16x16.png">
        <!-- Title -->
        <title>Home - Combocloud</title>
        <!-- Styles -->
        <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900&amp;display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="<?= base_url(); ?>assets/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?= base_url(); ?>assets/assets/plugins/font-awesome/css/all.min.css" rel="stylesheet">
        <!-- Theme Styles -->
        <link href="<?= base_url(); ?>assets/assets/css/lime.min.css" rel="stylesheet">
        <link href="<?= base_url(); ?>assets/assets/css/themes/admin2.css" rel="stylesheet">
        <link href="<?= base_url(); ?>assets/assets/css/custom.css" rel="stylesheet">
        <!-- Dashboard -->
        <link href="<?= base_url(); ?>assets/1-10-20/css/datatables.bootstrap4.min.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        <div class="lime-sidebar">
            <div class="lime-sidebar-inner slimscroll">
                <ul class="accordion-menu">
                                        <li class="sidebar-title">Main Menu</li>
                    <li><a href="auth/login.html"><i class="material-icons">home</i>Login</a></li>
                    <li><a href="auth/signup.html"><i class="material-icons">dashboard</i>Sign Up</a></li>
                                    </ul>
            </div>
        </div>
    <div class="container" style="
    margin: 0;
    position: absolute;
    top: 50%;
    left: 50%;
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
">
        <div class="container">
            <div class="row">
            <div class="col-md-8 col-md-offset-3">
                <img src="<?= base_url(); ?>assets/frjkvjg.png" height="25"><br><br>
                <h4 style="color: #f5f5f5;padding-bottom: 10px;"><strong>We are a cloud based combo and database provider, the #1 place to find the best combos and databases for all of your needs.</strong></h4>
                    <div class="row"> <div class="col-md-0" style=" padding-left: 15px; "> <i class="fas fa-star"></i> </div> <div class="col-md-11" style=" padding-left: 15px; ">We dump our combos<small>/</small>databases from the best sources to ensure the highest quality.</div> </div>
                    <div class="row"> <div class="col-md-0" style=" padding-left: 16px; "> <i class="fas fa-shield-alt"></i> </div> <div class="col-md-11" style=" padding-left: 16px; ">We ensure that our combos are as private as possible, so every hit is all yours.</div> </div>
                    <div class="row"> <div class="col-md-0" style=" padding-left: 15px; "> <i class="fas fa-shopping-cart"></i> </div> <div class="col-md-11" style=" padding-left: 16px; ">Purchase a membership and get 20 downloads a day, which equals up to around 1m lines a day.</div> </div>
                    <div class="row"> <div class="col-md-0" style=" padding-left: 16px; "> <i class="fas fa-server"></i> </div> <div class="col-md-11" style=" padding-left: 16px; ">Active subscribers are able to download frequently updates proxies.</div> </div>
                <p>
                    <div class="row" style=" padding-bottom: 1px; "> <span class="col-md-0" style=" padding-left: 15px; "><strong>Databases: </strong></span> <span class="col-md-0" style="padding-left: 15px"><kbd>5.291</kbd></span> </div>
                    <div class="row"> <span class="col-md-0" style="padding-left: 15px;padding-bottom: 5px; "><strong>Total Lines: </strong></span> <span class="col-md-0" style="padding-left: 19px"><kbd>863.187.499</kbd></span> </div>
                </p>
                <div class="row">
                                        <div class="col-md-2">
                                            <a href="<?= base_url(); ?>auth/login" class="btn btn-info btn-block">Login</a>
                                        </div>
                                        <div class="col-md-2" style="margin-left: -25px;">
                                            <a href="<?= base_url(); ?>auth/signup" class="btn btn-info btn-block">Register</a>
                                        </div>
                                    </div>
                <br><br>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                                <div class="card-body">
                                    <h4 class="card-title"><strong>Purchase Subscription</strong></h4>
                                    <p class="card-text">30 Downloads per day<br>
                                        Access to the "unlimited" section<br>
                                        Free proxies access<p>
                                    <button data-sellix-product="5eab6ec1259bd" type="button" class="btn btn-info btn-block" style="margin-top:20px;">Purchase 7 Days Access</button>
                                    <button data-sellix-product="5eab6ecf71954" type="button" class="btn btn-info btn-block" style="margin-top:15px;margin-bottom:15px;">Purchase 30 Days Access</button>
                                    <a href="https://discord.gg/cvVzpcJ" target="_blank" class="btn btn-outline-info btn-block" role="button" aria-pressed="true"><i class="fab fa-discord"></i> &nbsp; Join our Discord server</a>
                                </div>
                            </div>
            </div>
        </div>
        </div>
    </div>
        </div>
        <!-- Javascripts -->
        <script type="text/javascript" src="<?= base_url(); ?>assets/static/js/embed.js"></script>
        <script src="<?= base_url(); ?>assets/ajax/libs/jquery/3-5-0/jquery.min.js"></script>
        <script src="<?= base_url(); ?>assets/assets/plugins/bootstrap/popper.min.js"></script>
        <script src="<?= base_url(); ?>assets/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?= base_url(); ?>assets/assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
        <script src="<?= base_url(); ?>assets/assets/js/lime.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
        <script src='https://shoppy.gg/api/embed.js'></script>
        <!-- Dashboard DataTables -->
        <script>
            $(document).ready(function() {
                $('#example').DataTable( {
                    "order": [[ 0, "desc" ]]
                } );
            } );
        </script>
        <!-- Bootstrap Notify -->
        <script src="<?= base_url(); ?>assets/assets/js/bootstrap-notify.min.js"></script>
                    <script type="text/javascript">
                        $(document).ready(function(){
                            //Welcome Message (not for login page)
                            function notify(message, type){
                                $.notify({
                                    message: message
                                },{
                                    type: type,
                                    allow_dismiss: false,
                                    label: 'Cancel',
                                    placement: {
                                        from: 'bottom',
                                        align: 'left'
                                    },
                                    delay: 2500,
                                    animate: {
                                            enter: 'animated fadeInUp',
                                            exit: 'animated fadeOutDown'
                                    },
                                    offset: {
                                        x: 30,
                                        y: 30
                                    }
                                });
                            }
                                                                                });
                    </script>
</body>
</html>