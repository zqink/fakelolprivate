
        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->
        <div class="wrapper">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <h4 class="page-title">&nbsp;</h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
				<div class="row d-flex justify-content-center">
                    <div class="col-xl-3">
                        <div class="card-box widget-user">
                            <div class="text-center">
                                <h2 class="font-weight-normal text-primary" data-plugin="counterup"><?= $statistics['amount_combolists']; ?></h2>
                                <h5>Combolists</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3">
                        <div class="card-box widget-user">
                            <div class="text-center">
                                <h2 class="font-weight-normal text-pink" data-plugin="counterup"><?= $statistics['amount_lines']; ?></h2>
                                <h5>Credentials</h5>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="row d-flex justify-content-center">
                    <div class="col-xl-3">
                        <div class="card-box widget-user">
                            <div class="text-center">
                                <h2 class="font-weight-normal text-warning" data-plugin="counterup"><?= $statistics['amount_users']; ?></h2>
                                <h5>Users</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3">
                        <div class="card-box widget-user">
                            <div class="text-center">
                                <h2 class="font-weight-normal text-info" data-plugin="counterup"><?= $statistics['days_online']; ?></h2>
                                <h5>Days Online</h5>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->       

            </div>
            <!-- end container -->
        </div>
        <!-- end wrapper -->

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->