
	<script src='https://shoppy.gg/api/embed.js'></script>
	</body>
</html>