            <div class="lime-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <span class="footer-text" align="center">
                                
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        
        <!-- Javascripts -->
        <script type="text/javascript" src="https://cdn.sellix.io/static/js/embed.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>
        <script src="<?= base_url(); ?>assets/assets/plugins/bootstrap/popper.min.js"></script>
        <script src="<?= base_url(); ?>assets/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?= base_url(); ?>assets/assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
        <script src="<?= base_url(); ?>assets/assets/js/lime.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
        <script src='https://shoppy.gg/api/embed.js'></script>

        <!-- Dashboard DataTables -->
        <script>
            $(document).ready(function() {
                $('#example').DataTable( {
                    "order": [[ 0, "desc" ]]
                } );
            } );
        </script>

        <!-- Bootstrap Notify -->
        <script src="<?= base_url(); ?>assets/assets/js/bootstrap-notify.min.js"></script>
                    <script type="text/javascript">
                        $(document).ready(function(){
                            //Welcome Message (not for login page)
                            function notify(message, type){
                                $.notify({
                                    message: message
                                },{
                                    type: type,
                                    allow_dismiss: false,
                                    label: 'Cancel',
                                    placement: {
                                        from: 'bottom',
                                        align: 'left'
                                    },
                                    delay: 2500,
                                    animate: {
                                            enter: 'animated fadeInUp',
                                            exit: 'animated fadeOutDown'
                                    },
                                    offset: {
                                        x: 30,
                                        y: 30
                                    }
                                });
                            }
             <?php if (count($this->session->flashdata()) != 0): ?>
                  <?php foreach($this->session->flashdata() as $message): ?>
                                                                                                notify('<?= $message['message']; ?>', '<?= $message['status']; ?>');
																								                  <?php endforeach; ?>
              <?php endif; ?>
                                                                                                                });
                    </script>
    </body>
</html>