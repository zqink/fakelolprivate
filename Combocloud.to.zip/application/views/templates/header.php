<!DOCTYPE html>
<html>
	<head>
		<title><?= $title; ?> - <?= $this->config->item('website_name'); ?></title>
		<link rel="stylesheet" href="https://bootswatch.com/4/flatly/bootstrap.css">
		<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
		<link href="<?= base_url(); ?>assets/css/style.css" rel="stylesheet">
		<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.6/css/flag-icon.min.css" rel="stylesheet">

		<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
		<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
		<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
		<script src="https://bootswatch.com/_vendor/bootstrap/dist/js/bootstrap.min.js"></script>

	</head>
	<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
		  <a class="navbar-brand" href="<?= base_url(); ?>"><?= $this->config->item('website_name'); ?></a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <?php if (!$this->session->user_id): ?>
		  <div class="collapse navbar-collapse" id="navbarColor01">
		    <ul class="navbar-nav mr-auto">
		      <li class="nav-item">
		        <a class="nav-link" href="<?= base_url(); ?>">Home</a>
		      </li>
		    </ul>
		    <div class="my-2 my-lg-0">
			    <ul class="navbar-nav mr-auto">
			      <li class="nav-item">
			        <a class="nav-link" href="<?= base_url(); ?>auth/login">Login</a>
			      </li>
			      <li class="nav-item">
			        <a class="nav-link" href="<?= base_url(); ?>auth/signup">Signup</a>
			      </li>
			    </ul>
			</div>
		  </div>
		  <?php else: ?>
		  <div class="collapse navbar-collapse" id="navbarColor01">
		    <ul class="navbar-nav mr-auto">
		      <li class="nav-item">
		        <a class="nav-link" href="<?= base_url(); ?>">Home</a>
		      </li>
		    </ul>
		    <div class="my-2 my-lg-0">
			    <ul class="navbar-nav mr-auto">
			    	<?php if($this->auth_model->is_admin()): ?>
			      <li class="nav-item">
			        <a class="nav-link" href="<?= base_url(); ?>admin">Admin</a>
			      </li>
			    	<?php endif; ?>
			      <li class="nav-item">
			        <a class="nav-link" href="<?= base_url(); ?>dashboard">Dashboard</a>
			      </li>
			      <li class="nav-item">
			        <a class="nav-link" href="<?= base_url(); ?>auth/logout">Logout</a>
			      </li>
			    </ul>
			</div>
		  </div>
		  <?php endif; ?>
		</nav>
		<?php if (count($this->session->flashdata()) != 0): ?>
		<div class="container" style="margin-top: 2em;">
			<div class="row">
	        	<div class="col-lg-12">
				<?php foreach($this->session->flashdata() as $message): ?>
				  <div class="alert alert-dismissible alert-<?= $message['status']; ?>">
				  	<?= $message['message']; ?>
				  </div>
				<?php endforeach; ?>
	        	</div>
	        </div>
		</div>
		<?php endif; ?>
		<?php if (validation_errors()): ?>
		<div class="container" style="margin-top: 2em;">
			<div class="row">
	        	<div class="col-lg-12">
					<?= validation_errors('<div class="alert alert-dismissible alert-danger">', '</div>'); ?>
	        	</div>
	        </div>
		</div>
		<?php endif; ?>

		<?php if(isset($is_adminpage) && $is_adminpage): ?>
		<div class="container" style="margin-top: 4em;">
			<div class="row">
	        	<div class="col-lg-12">
					<div class="card text-white bg-primary mb-3">
					  <div class="card-header" align="center"><b>Admin Navigation</b></div>
					  <div class="card-body">
					    <p class="card-text" align="center">
					    	<a class="btn btn-secondary" href="<?= base_url(); ?>admin">Home</a>
					    	<a class="btn btn-secondary" href="<?= base_url(); ?>admin/add_combo">Add Combo</a>
					    	<a class="btn btn-secondary" href="<?= base_url(); ?>admin/delete_combo">Delete Combo</a>
					    	<a class="btn btn-secondary" href="<?= base_url(); ?>admin/add_category">Add Group</a>
					    	<a class="btn btn-secondary" href="<?= base_url(); ?>admin/delete_category">Delete Group</a>
					    	<a class="btn btn-secondary" href="<?= base_url(); ?>admin/key_generator">Generate Keys</a>
					    	<a class="btn btn-secondary" href="<?= base_url(); ?>admin/check_key">Check Key</a>
					    	<a class="btn btn-secondary" href="<?= base_url(); ?>admin/manage_bans">Manage Bans</a>
					    </p>
					  </div>
					</div>
	        	</div>
	        </div>
		</div>
		<?php endif; ?>