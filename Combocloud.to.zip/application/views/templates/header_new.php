<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Combocloud is a cloud based combo and database provider, the place to find the best combos and databases for all of your needs.">
        <meta name="keywords" content="Combocloud, Priv8.to">
        <meta name="author" content="Combocloud.to">
        <!-- The above 6 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        
        <script src="<?= base_url(); ?>assets/cdn-cgi/apps/head/h94fYuDBsvPuE9sn3pL-FNtjmPY.js"></script><link rel="apple-touch-icon" sizes="180x180" href="<?= base_url(); ?>assets/assets/images/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url(); ?>assets/assets/images/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url(); ?>assets/assets/images/favicon-16x16.png">
        
        <!-- Title -->
        <title><?= $title; ?> - Combocloud</title>

        <!-- Styles -->
        <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900&amp;display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="<?= base_url(); ?>assets/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?= base_url(); ?>assets/assets/plugins/font-awesome/css/all.min.css" rel="stylesheet">

      
        <!-- Theme Styles -->
        <link href="<?= base_url(); ?>assets/assets/css/lime.min.css" rel="stylesheet">
        <link href="<?= base_url(); ?>assets/assets/css/themes/admin2.css" rel="stylesheet">
        <link href="<?= base_url(); ?>assets/assets/css/custom.css" rel="stylesheet">

        <!-- Dashboard -->
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet">

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    </head>
    <body>
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>
        
        <div class="lime-sidebar">
            <div class="lime-sidebar-inner slimscroll">
                <ul class="accordion-menu">
                                        <li class="sidebar-title">Main Menu</li>
                    <li><a href="<?= base_url(); ?>dashboard"><i class="material-icons">home</i>Dashboard</a></li>
                    <li>
                        <a href="#"><i class="material-icons">list</i>Categories<i class="material-icons has-sub-menu">keyboard_arrow_left</i></a>
                        <ul class="sub-menu" style="display: none;">
                            <li>
							<?php foreach ($combo_groups as $combo_group): ?>

                                                                 <a href="<?= base_url(); ?>dashboard/combogroup/<?= $combo_group['id']; ?>">
                                    <div class="row">
                                        <div class="col-md-10">
                                            <?= $combo_group['name']; ?>                                        </div>
                                    </div>
                                </a>
								<?php endforeach; ?>
                                                            </li>
                        </ul>
                    </li>
                    <li><a href="<?= base_url(); ?>dashboard/renew"><i class="material-icons">shopping_cart</i>Purchase / Redeem</a></li>
                    <li><a href="<?= base_url(); ?>auth/logout"><i class="material-icons">directions_walk</i>Logout</a></li>
                    
                    <li class="sidebar-title">Extra</li>
                    <li><a href="<?= base_url(); ?>dashboard/proxies"><i class="material-icons">vpn_lock</i>Proxies</a></li>
                    <li><a href="https://discord.gg/cvVzpcJ" target="_blank"><i class="fab fa-discord"></i>Discord</a></li>
					                    <li class="sidebar-title">Admin</li>
										<li><a href="<?= base_url(); ?>" target="_blank"><i class="fab fa-lock"></i>Add combo</a></li>
										<li><a href="<?= base_url(); ?>admin/delete_combo" target="_blank"><i class="fab fa-lock"></i>delete combo</a></li>
										<li><a href="<?= base_url(); ?>admin/add_category" target="_blank"><i class="fab fa-lock"></i>add category</a></li>
										<li><a href="<?= base_url(); ?>admin/delete_category" target="_blank"><i class="fab fa-lock"></i>delete category</a></li>
										<li><a href="<?= base_url(); ?>admin/key_generator" target="_blank"><i class="fab fa-lock"></i>key generator</a></li>
										<li><a href="<?= base_url(); ?>admin/manage_bans" target="_blank"><i class="fab fa-lock"></i>manage bans</a></li>
										
										

                                                        </ul>
            </div>
        </div>
        
        <div class="lime-header">
            <nav class="navbar navbar-expand-lg">
                <section class="material-design-hamburger navigation-toggle">
                    <a href="javascript:void(0)" class="button-collapse material-design-hamburger__icon">
                        <span class="material-design-hamburger__layer"></span>
                    </a>
                </section>
                <img src="<?= base_url(); ?>assets/logo.png" height="22" width="22">
                <a class="navbar-brand" href="<?= base_url(); ?>">Combocloud</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="material-icons">keyboard_arrow_down</i>
                </button>
            
            </nav>
        </div>